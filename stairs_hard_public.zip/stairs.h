#include <vector>

int countWays(long long N, int M, std::vector<int> S);