#include <vector>
#include "stairs.h"

int countWays(long long N, int M, std::vector<int> S){
    // edit this
    return 0;
}