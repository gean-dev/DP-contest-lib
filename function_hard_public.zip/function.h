#include <vector>

long long minPenguinValue(int N, int M, std::vector<int> A);