#include <vector>
#include "function.h"

long long minPenguinValue(int N, int M, std::vector<int> A){
    // edit this
    return 0ll;
}