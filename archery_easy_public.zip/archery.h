#include <vector>

long long minPenguinCoin(int N, std::vector<int> A, std::vector<int> U, std::vector<int> D);