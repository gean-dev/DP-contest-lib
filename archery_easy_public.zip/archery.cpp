#include <vector>
#include "archery.h"

long long minPenguinCoin(int N, std::vector<int> A, std::vector<int> U, std::vector<int> D){
    // edit this
    return 0ll;
}