#include <vector>

int countWays(int N, int M, std::vector<int> S);